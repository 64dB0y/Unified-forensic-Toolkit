import os

# 각 카테고리 디렉토리 설정
categories = {
    1: "Logon",
    2: "Network",
    3: "System_info",
    4: "autorun",
    5: "log",
    6: "process",
    7: "shortcut",
    8: "Web",
    9: "all"
}

# 카테고리 목록 출력
for key, value in categories.items():
    print(f"{key}. {value}")

# 사용자로부터 카테고리 선택
selected_category = int(input("PDF로 변환할 카테고리 번호를 입력하세요: "))

# 선택한 카테고리가 유효한지 확인
if selected_category not in categories:
    print("유효하지 않은 카테고리 번호입니다.")
else:
    if categories[selected_category] == "all":
        # 1부터 8까지의 카테고리의 파이썬 스크립트를 실행
        for category_directory in range(1, 9):
            os.chdir(categories[category_directory])
            for filename in os.listdir():
                if filename.endswith(".py"):
                    os.system(f"python {filename}")
            os.chdir("..")  # 다음 카테고리로 이동하기 전에 상위 디렉토리로 이동
    else:
        category_directory = categories[selected_category]

        # 해당 카테고리의 디렉토리로 이동
        os.chdir(category_directory)

        # 해당 카테고리의 파이썬 스크립트를 실행
        for filename in os.listdir():
            if filename.endswith(".py"):
                os.system(f"python {filename}")

        print(f"{category_directory} 카테고리의 파이썬 스크립트가 실행되었습니다.")
