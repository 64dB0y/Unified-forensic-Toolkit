n = 0

while(n != 5):
    n = input()
    n = int(n)
    if(n != 5):
        print("5가 아닙니다")